package com.rullion.rulliontasks;

import static org.junit.Assert.assertEquals;
import java.util.Arrays;
import java.util.Collections;
import org.junit.Before;
import org.junit.Test;
import com.rullion.exception.CyclicDependencyException;

public class PrintingTaskOrderTest {

  public PrintingTaskOrderTest() {}

  PrintingTaskOrder pto;

  @Before
  public void setUp() {
    pto = new PrintingTaskOrder();
  }

  @Test
  public void PrintTaskExecutionTest1() {
    String str =
        pto.printTasksExecution(Collections.<String>emptyList(), Collections.<String>emptyList());
    assertEquals("[]", str);
  }

  @Test
  public void PrintTaskExecutionTest2() {
    String str = pto.printTasksExecution(Arrays.asList("a", "b"), Collections.<String>emptyList());
    assertEquals("[a, b]", str);
  }

  @Test
  public void PrintTaskExecutionTest3() {
    String str = pto.printTasksExecution(Arrays.asList("a", "b"), Arrays.asList("a=>b"));
    assertEquals("[b, a]", str);
  }

  @Test
  public void PrintTaskExecutionTest4() {
    String str =
        pto.printTasksExecution(Arrays.asList("a", "b", "c", "d"), Arrays.asList("a=>b", "c=>d"));
    assertEquals("[b, a, d, c]", str);
  }

  @Test
  public void PrintTaskExecutionTest5() {
    String str =
        pto.printTasksExecution(Arrays.asList("a", "b", "c"), Arrays.asList("a=>b", "b=>c"));
    assertEquals("[c, b, a]", str);
  }

  @Test(expected = CyclicDependencyException.class)
  public void PrintTaskExecutionTest6() {
    pto.printTasksExecution(Arrays.asList("a", "b", "c", "d"),
        Arrays.asList("a=>b", "b=>c", "c=>a"));
  }

}
