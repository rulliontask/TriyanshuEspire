package com.rullion.rulliontasks;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import com.rullion.exception.CyclicDependencyException;

public class PrintingTaskOrder {

  public void inputTaskDependency(List<String> taskList, List<String> dependencyList) {
    try (Scanner sc = new Scanner(System.in)) {
      String task_dependency = "";
      System.out
          .println("Enter tasks and their dependencies and type 'stop' to stop entering values");
      System.out.println("Please enter tasks:");
      while (!task_dependency.equals("stop")) {
        task_dependency = sc.next();
        if (!task_dependency.equals("stop")) {
          taskList.add(task_dependency);
        }
      }
      System.out
          .println("Enter dependencies in format i.e. task1=>task2 means task1 depends on task2");
      System.out.println("Please enter dependencies:");
      task_dependency = "";

      while (!task_dependency.equals("stop")) {
        task_dependency = sc.next();
        if (!task_dependency.equals("stop")) {
          dependencyList.add(task_dependency);
        }
      }
      System.out.println("tasks: " + taskList);
      System.out.println("dependencies: " + dependencyList);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public void createDependencyMap(List<String> taskList, List<String> dependencyList,
      Map<String, List<String>> task_dependencyMap) {
    taskList.forEach(task -> {
      task_dependencyMap.put(task, new ArrayList<String>());
    });
    dependencyList.forEach(dependency -> {
      task_dependencyMap.get(dependency.split("=>")[0]).add(dependency.split("=>")[1]);
    });
  }

  public String printTasksExecution(List<String> taskList, List<String> dependencyList) {
    List<String> partiallyExecute = new LinkedList<>();
    List<String> executedTasks = new LinkedList<>();
    List<String> resultList = new LinkedList<>();
    Map<String, List<String>> task_dependencyMap = new HashMap<>();

    createDependencyMap(taskList, dependencyList, task_dependencyMap);
    // Recursively search for tasks those are not executed yet.
    taskList.forEach(task -> {
      try {
        if (!executedTasks.contains(task)) {
          search(task, task_dependencyMap, partiallyExecute, executedTasks, resultList);
        }
      } catch (CyclicDependencyException ce) {
        throw ce;
      }
    });

    return resultList.toString();
  }

  // Search through all non executed task, check them if they are partially executed or complete
  // executed
  public void search(String task, Map<String, List<String>> task_dependencyMap,
      List<String> partiallyExecute, List<String> executedTasks, List<String> resultList) {
    // Throw an error if cyclic dependency found
    if (checkCyclicDependency(task, partiallyExecute)) {
      throw new CyclicDependencyException("Error - this is a cyclic dependency!");
    }

    // If we haven't executed the task, recursively search from there
    if (!executedTasks.contains(task)) {
      partiallyExecute.add(task);

      // Perform recursive search
      if (!task_dependencyMap.get(task).isEmpty()) {
        task_dependencyMap.get(task).forEach(t -> {
          search(t, task_dependencyMap, partiallyExecute, executedTasks, resultList);
        });
      }
      // Add complete executed, remove partially executed, and add to resultList
      executedTasks.add(task);
      partiallyExecute.remove(task);
      resultList.add(task);
    }
  }

  private boolean checkCyclicDependency(String task, List<String> partiallyExecute) {
    if (partiallyExecute.contains(task))
      return true;
    else
      return false;
  }

}

