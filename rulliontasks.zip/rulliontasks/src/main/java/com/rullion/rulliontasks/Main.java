package com.rullion.rulliontasks;

import java.util.ArrayList;
import java.util.List;
import com.rullion.exception.CyclicDependencyException;


public class Main {
  public static void main(String[] args) {
    try {
      List<String> taskList = new ArrayList<>();
      List<String> dependencyList = new ArrayList<>();

      PrintingTaskOrder pto = new PrintingTaskOrder();
      // Input Tasks and Dependencies
      pto.inputTaskDependency(taskList, dependencyList);

      // Print tasks and dependencies execution
      String result = pto.printTasksExecution(taskList, dependencyList);

      System.out.println("result: " + result);
    } catch (Exception e) {
      if (e instanceof CyclicDependencyException)
        System.out.println("result: " + e.getMessage());
      else
        e.printStackTrace();
    }
  }

}
